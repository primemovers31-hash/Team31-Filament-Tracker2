var SHEET_NAME = 'Sheet1';
var STATUS_HEADER = 'Status';
var UPDATED_HEADER = 'Last updated';
var COMMENTS_HEADER = 'Comments';

function doGet(e) {
  var a = (e.parameter.action || 'list');
  try {
    if (a === 'list') return out_(e, { ok: true, spools: listSpools_() });
    if (a === 'updateStatus') { updateStatus_(e.parameter.id, e.parameter.status); return out_(e, { ok: true }); }
    if (a === 'updateNotes') { updateNotes_(e.parameter.id, e.parameter.notes || ''); return out_(e, { ok: true }); }
    if (a === 'ping') return out_(e, { ok: true, message: 'Apps Script is live.' });
    return out_(e, { ok: false, error: 'Unknown action.' });
  } catch (err) {
    return out_(e, { ok: false, error: err.message || String(err) });
  }
}

function out_(e, payload) {
  var cb = e.parameter.callback;
  if (cb) return ContentService.createTextOutput(cb + '(' + JSON.stringify(payload) + ');').setMimeType(ContentService.MimeType.JAVASCRIPT);
  return ContentService.createTextOutput(JSON.stringify(payload)).setMimeType(ContentService.MimeType.JSON);
}

function sheet_() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  return ss.getSheetByName(SHEET_NAME) || ss.getSheets()[0];
}

function headers_(sh) {
  return sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function(h) { return String(h || '').trim(); });
}

function idx_(headers, name) {
  return headers.indexOf(name);
}

function ensureHeader_(sh, headers, name) {
  if (idx_(headers, name) !== -1) return headers;
  headers.push(name);
  sh.getRange(1, headers.length).setValue(name);
  return headers;
}

function listSpools_() {
  var sh = sheet_(), headers = headers_(sh), rows = sh.getRange(2, 1, Math.max(sh.getLastRow() - 1, 0), headers.length).getValues();
  return rows.filter(function(r) { return r.join('') !== ''; }).map(function(r) {
    var o = {}; headers.forEach(function(h, i) { o[h] = r[i]; });
    var filament = txt_(o['Filament type']), specifics = txt_(o['Specifics (if neccessary)']), color = txt_(o['Color']), location = txt_(o['Location']) || txt_(o['Location ']);
    return {
      id: Math.round(Number(o['Asset tag']) || 0),
      filamentType: filament || 'Unknown',
      detailedType: specifics && specifics.toLowerCase() !== 'normal' ? filament + ' ' + specifics : filament,
      colorRgba: colorToArgb_(color),
      colorNameText: color || 'Unknown',
      status: txt_(o[STATUS_HEADER]) || deriveStatus_(location, o['Amount remaining (approximate)']),
      notes: txt_(o[COMMENTS_HEADER]),
      brand: txt_(o['Brand']),
      sealed: txt_(o['Sealed']),
      location: location,
      amountRemaining: txt_(o['Amount remaining (approximate)']),
      orderAgain: txt_(o['Order again']),
      tagUid: '', productionDate: '', weightGrams: 0, diameterMm: 0, lengthMeters: 0,
      minHotendTempC: 0, maxHotendTempC: 0, bedTempC: 0, dryingTempC: 0, dryingTimeHours: 0,
      dateLastScanned: Number(o[UPDATED_HEADER]) || 0
    };
  });
}

function updateStatus_(id, status) {
  var sh = sheet_(), headers = headers_(sh), row = rowById_(sh, headers, id);
  headers = ensureHeader_(sh, headers, STATUS_HEADER);
  headers = ensureHeader_(sh, headers, UPDATED_HEADER);
  sh.getRange(row, idx_(headers, STATUS_HEADER) + 1).setValue(status);
  sh.getRange(row, idx_(headers, UPDATED_HEADER) + 1).setValue(Date.now());
}

function updateNotes_(id, notes) {
  var sh = sheet_(), headers = headers_(sh), row = rowById_(sh, headers, id);
  headers = ensureHeader_(sh, headers, COMMENTS_HEADER);
  headers = ensureHeader_(sh, headers, UPDATED_HEADER);
  sh.getRange(row, idx_(headers, COMMENTS_HEADER) + 1).setValue(notes);
  sh.getRange(row, idx_(headers, UPDATED_HEADER) + 1).setValue(Date.now());
}

function rowById_(sh, headers, id) {
  var col = idx_(headers, 'Asset tag'); if (col === -1) throw new Error('Missing Asset tag column.');
  var vals = sh.getRange(2, col + 1, Math.max(sh.getLastRow() - 1, 0), 1).getValues(), needle = String(Math.round(Number(id) || 0));
  for (var i = 0; i < vals.length; i++) if (String(Math.round(Number(vals[i][0]) || 0)) === needle) return i + 2;
  throw new Error('Asset tag ' + id + ' not found.');
}

function txt_(v) { return v == null ? '' : String(v).trim(); }

function deriveStatus_(location, amount) {
  var loc = txt_(location).toLowerCase(), amt = txt_(amount).toLowerCase();
  if (loc.indexOf('printer') !== -1) return 'IN_USE';
  if (amt === '0' || amt === '0.0' || amt === 'empty' || amt === 'used up' || amt === 'none') return 'USED_UP';
  return 'IN_STOCK';
}

function colorToArgb_(name) {
  var s = txt_(name).toLowerCase(), m = { black:'000000', white:'ffffff', red:'c12e1f', 'ruby red':'9b111e', maroon:'800000', blue:'0056b8', green:'00ae42', yellow:'f4ee2a', orange:'ff9016', purple:'5e43b7', pink:'f55a74', gray:'8e9089', grey:'8e9089', silver:'d1d3d5', brown:'9d432c' };
  var hex = m[s] || (s.indexOf('red') !== -1 ? 'c12e1f' : s.indexOf('black') !== -1 ? '000000' : s.indexOf('blue') !== -1 ? '0056b8' : s.indexOf('green') !== -1 ? '00ae42' : s.indexOf('yellow') !== -1 ? 'f4ee2a' : s.indexOf('orange') !== -1 ? 'ff9016' : s.indexOf('purple') !== -1 ? '5e43b7' : s.indexOf('pink') !== -1 ? 'f55a74' : s.indexOf('brown') !== -1 ? '9d432c' : s.indexOf('gray') !== -1 || s.indexOf('grey') !== -1 ? '8e9089' : fallbackHex_(s));
  return parseInt('FF' + hex.toUpperCase(), 16);
}

function fallbackHex_(s) {
  var n = 0; for (var i = 0; i < s.length; i++) n = (n * 31 + s.charCodeAt(i)) & 0xffffff;
  return ('000000' + n.toString(16)).slice(-6);
}
