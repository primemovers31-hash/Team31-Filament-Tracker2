# Apps Script Setup

This folder contains a Google Apps Script backend for the GitHub Pages dashboard in `docs/`.

## Spreadsheet

Your existing Excel file uses a sheet named `Sheet1` with headers like these:

```text
Asset tag,Filament type,Specifics (if neccessary),Brand,Sealed,Location,Amount remaining (approximate),Order again,Comments,Color
```

That is what the provided `Code.gs` now expects.

If your Google Sheet came from the Excel import, keep the first tab as `Sheet1`.

The script will automatically add these columns if they do not already exist:

```text
Status, Last updated
```

## Deploy

1. Open [script.google.com](https://script.google.com/).
2. Create a new Apps Script project.
3. Copy in `Code.gs`.
4. Replace the generated `appsscript.json` with the one in this folder if you want matching settings.
5. Bind the Apps Script project to your spreadsheet.
6. Make sure it is attached to the spreadsheet that contains your imported filament data.
7. Click `Deploy` > `New deployment`.
8. Choose `Web app`.
9. Execute as: `Me`
10. Who has access: `Anyone`
11. Copy the `/exec` URL.

## Connect The Site

Paste your web app URL into:

`docs/config.js`

Example:

```js
window.APP_CONFIG = {
  appsScriptUrl: "https://script.google.com/macros/s/YOUR_DEPLOYMENT_ID/exec"
};
```
